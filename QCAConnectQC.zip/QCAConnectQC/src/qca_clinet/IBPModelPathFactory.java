package qca_clinet  ;

import com4j.*;

/**
 * Services for managing Business Process Model path.
 */
@IID("{23D9F08D-6D2A-4A36-BB97-EE1D8EA0BAB4}")
public interface IBPModelPathFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
