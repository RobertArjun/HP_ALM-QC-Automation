package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services to manage Dashboard Pages.
 */
@IID("{1001E71F-5744-4624-8000-633698EB940D}")
public interface IDashboardPageFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  /**
   * <p>
   * Returns those dashboard page objects from the specified ID list that include private analysis items.
   * </p>
   * @param pIdsList Mandatory qca_clinet.IList parameter.
   * @return  Returns a value of type qca_clinet.IList
   */

  @DISPID(9) //= 0x9. The runtime will prefer the VTID if present
  @VTID(17)
  qca_clinet.IList getPagesWithPrivateItems(
    qca_clinet.IList pIdsList);


  // Properties:
}
