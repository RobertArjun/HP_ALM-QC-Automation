package qca_clinet  ;

import com4j.*;

/**
 * An instance of a TestCriterion created when the associated TestConfig is run.
 */
@IID("{8846BE03-6CF5-4B69-94D1-99B11B325936}")
public interface IRunCriterion extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
