package qca_clinet  ;

import com4j.*;

/**
 * Represents a type of user action. Actions are listed in the AC_ACTION_NAME field of the Actions table.
 */
@IID("{B1C48875-CE4E-4740-B04C-9FAF1A6F25D7}")
public interface ICustomizationAction4 extends qca_clinet.ICustomizationAction3 {
  // Methods:
  /**
   * <p>
   * A list of the user groups for which the current action is allowed in Owner Only mode.
   * </p>
   * <p>
   * Getter method for the COM property "OwnerOnlyGroups"
   * </p>
   * @return  Returns a value of type qca_clinet.IList
   */

  @DISPID(14) //= 0xe. The runtime will prefer the VTID if present
  @VTID(22)
  qca_clinet.IList ownerOnlyGroups();


  @VTID(22)
  @ReturnValue(type=NativeType.VARIANT,defaultPropertyThrough={qca_clinet.IList.class})
  java.lang.Object ownerOnlyGroups(
    int index);

  /**
   * <p>
   * Adds a user group to the list of user groups for which the current action is allowed. 
   * </p>
   * @param group Mandatory java.lang.Object parameter.
   */

  @DISPID(15) //= 0xf. The runtime will prefer the VTID if present
  @VTID(23)
  void addGroupAsOwnerOnly(
    @MarshalAs(NativeType.VARIANT) java.lang.Object group);


  // Properties:
}
