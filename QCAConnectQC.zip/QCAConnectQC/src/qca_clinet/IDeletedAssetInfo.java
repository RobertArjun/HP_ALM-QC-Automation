package qca_clinet  ;

import com4j.*;

/**
 * Represents a deleted asset.
 */
@IID("{39C026BE-DE9C-457C-B529-CD7F1F0524DD}")
public interface IDeletedAssetInfo extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
