package qca_clinet  ;

import com4j.*;

/**
 * KPIMilestoneScopeItem Factory
 */
@IID("{F631190A-C557-4EC1-8773-2FA3A708F8F9}")
public interface IKPIMilestoneScopeItemFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
