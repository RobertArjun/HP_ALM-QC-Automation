package qca_clinet  ;

import com4j.*;

/**
 * Diagram Factory
 */
@IID("{A3BF87FA-AABC-4A2B-B251-73B1AF3C4EB0}")
public interface IDiagramFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
