package qca_clinet  ;

import com4j.*;

/**
 * Represents a single server connection.
 */
@IID("{62D83266-71EF-4F8B-8AE6-661D614D0769}")
public interface ITDConnection11 extends qca_clinet.ITDConnection10 {
  // Methods:
  /**
   * <p>
   * For HP use. The factory that manages ALM environments.
   * </p>
   * <p>
   * Getter method for the COM property "AlmEnvironmentFactory"
   * </p>
   * @return  Returns a value of type com4j.Com4jObject
   */

  @DISPID(226) //= 0xe2. The runtime will prefer the VTID if present
  @VTID(230)
  @ReturnValue(type=NativeType.Dispatch)
  com4j.Com4jObject almEnvironmentFactory();


  /**
   * <p>
   * For HP use. Get server setting by it's name
   * </p>
   * @param settingName Mandatory java.lang.String parameter.
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(227) //= 0xe3. The runtime will prefer the VTID if present
  @VTID(231)
  java.lang.String getServerSetting(
    java.lang.String settingName);


  // Properties:
}
