package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Represents a run result factory.
 */
@IID("{8FECD837-0B81-4A5B-BBE6-D26DB0F97C4E}")
public interface IResultFactory extends qca_clinet.IBaseFactory {
  // Methods:
  // Properties:
}
