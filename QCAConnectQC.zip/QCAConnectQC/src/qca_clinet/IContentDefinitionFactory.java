package qca_clinet  ;

import com4j.*;

/**
 * Represents a Content Definition Factory.
 */
@IID("{9BD5C80D-B434-4E97-A69C-A13549A2539C}")
public interface IContentDefinitionFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
