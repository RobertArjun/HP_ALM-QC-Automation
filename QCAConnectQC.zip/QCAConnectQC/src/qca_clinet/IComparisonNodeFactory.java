package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services for managing comparisons.
 */
@IID("{ADF1AF0C-EC7F-4466-ACC8-300DE3F053EC}")
public interface IComparisonNodeFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
