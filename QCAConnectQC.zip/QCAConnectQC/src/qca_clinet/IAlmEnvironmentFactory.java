package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services to manage ALM environments.
 */
@IID("{D71F62B3-2CCE-4AC0-9A15-07FD8355DE5D}")
public interface IAlmEnvironmentFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
