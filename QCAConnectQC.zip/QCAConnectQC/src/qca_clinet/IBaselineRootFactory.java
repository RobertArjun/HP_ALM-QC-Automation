package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services for managing Baseline Roots
 */
@IID("{E801BB54-EC2E-44EB-9115-7B39D54CD89E}")
public interface IBaselineRootFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
