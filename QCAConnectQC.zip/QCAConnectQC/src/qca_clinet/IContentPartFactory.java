package qca_clinet  ;

import com4j.*;

/**
 * Represents a Content Part Factory.
 */
@IID("{264E6DB2-2574-433E-A264-A1BB8CE8459F}")
public interface IContentPartFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
