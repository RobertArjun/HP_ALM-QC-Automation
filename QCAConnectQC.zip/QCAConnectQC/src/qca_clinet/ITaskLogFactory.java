package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services for logging messages on asynchronous actions.
 */
@IID("{B1EDCB29-F5C2-4A61-BA97-766D92B3D265}")
public interface ITaskLogFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
