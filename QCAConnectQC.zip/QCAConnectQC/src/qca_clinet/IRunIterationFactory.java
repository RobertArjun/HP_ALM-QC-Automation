package qca_clinet  ;

import com4j.*;

/**
 * Services for managing run iterations.
 */
@IID("{5577BD5B-BF4A-4A34-B470-D5F20E60A227}")
public interface IRunIterationFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
