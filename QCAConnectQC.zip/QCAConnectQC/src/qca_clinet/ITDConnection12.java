package qca_clinet  ;

import com4j.*;

/**
 * Represents a single server connection.
 */
@IID("{5FFC8521-6228-433D-B6DE-0D24E9E1B2D2}")
public interface ITDConnection12 extends qca_clinet.ITDConnection11 {
  // Methods:
  /**
   * <p>
   * Allocates multiple licenses types according to the LicensesType parameter.
   * </p>
   * @param licenseType Mandatory long parameter.
   * @param pVal Mandatory Holder<java.lang.String> parameter.
   */

  @DISPID(228) //= 0xe4. The runtime will prefer the VTID if present
  @VTID(232)
  void getLicensesEx(
    long licenseType,
    Holder<java.lang.String> pVal);


  // Properties:
}
