package qca_clinet  ;

import com4j.*;

/**
 * Represents a deleted assets factory.
 */
@IID("{21823396-E1CF-4328-94AA-0891B14D83E8}")
public interface IDeletedAssetInfoFactory extends qca_clinet.IBaseFactory {
  // Methods:
  // Properties:
}
