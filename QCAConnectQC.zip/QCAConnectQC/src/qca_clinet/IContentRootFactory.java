package qca_clinet  ;

import com4j.*;

/**
 * Represents a Content Root Factory.
 */
@IID("{0DC28FC3-F456-438E-B351-0087EA5B3A6C}")
public interface IContentRootFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
