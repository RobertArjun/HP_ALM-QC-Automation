package qca_clinet  ;

import com4j.*;

/**
 * For HP use. A factory for IReportToReportProjectTemplateLink.
 */
@IID("{0D6AED70-CBDD-469B-8864-01A2F887665C}")
public interface IReportToReportProjectTemplateLinkFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
