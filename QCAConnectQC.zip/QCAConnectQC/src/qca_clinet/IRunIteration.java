package qca_clinet  ;

import com4j.*;

/**
 * Services for run iteration.
 */
@IID("{E5D84B97-219C-4698-ABEE-48F110755E2F}")
public interface IRunIteration extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
