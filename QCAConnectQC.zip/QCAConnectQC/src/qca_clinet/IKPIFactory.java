package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Represents a KPI Factory.
 */
@IID("{5EC0A34E-A6CB-477A-8789-E10C4469795C}")
public interface IKPIFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
