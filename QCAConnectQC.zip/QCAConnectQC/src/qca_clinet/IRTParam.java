package qca_clinet  ;

import com4j.*;

/**
 * Deprecated. Use ITestParameter. A Business Process Test runtime parameter.
 */
@IID("{E0C8D290-50AF-4811-A5FB-3ED5B78B99F3}")
public interface IRTParam extends qca_clinet.IBaseParam {
  // Methods:
  // Properties:
}
