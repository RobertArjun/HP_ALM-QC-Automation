package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services to manage items in a dashboard page.
 */
@IID("{81097265-9D90-4392-B226-BD2BA8D76006}")
public interface IDashboardPageItemFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
