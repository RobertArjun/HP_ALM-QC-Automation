package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Represents an ALM environment.
 */
@IID("{509315CC-A417-4FA6-A143-302BE3905A8C}")
public interface IAlmEnvironment extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
