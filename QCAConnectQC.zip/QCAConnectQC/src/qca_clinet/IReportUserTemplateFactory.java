package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Represents report user custom template.
 */
@IID("{455482A5-85F5-4562-921E-F80214C90EDA}")
public interface IReportUserTemplateFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
