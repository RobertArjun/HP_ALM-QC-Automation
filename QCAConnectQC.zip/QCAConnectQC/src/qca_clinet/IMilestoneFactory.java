package qca_clinet  ;

import com4j.*;

/**
 * Milestone Factory
 */
@IID("{F8019D12-757B-4605-9C73-7C1C6271A56E}")
public interface IMilestoneFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
