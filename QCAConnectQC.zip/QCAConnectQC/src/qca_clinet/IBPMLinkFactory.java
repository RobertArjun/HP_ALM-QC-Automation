package qca_clinet  ;

import com4j.*;

/**
 * For HP use. Services for managing traceability associations between requirements.
 */
@IID("{1BC95899-3B4D-4B79-94CC-56CB7B3E7B56}")
public interface IBPMLinkFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
