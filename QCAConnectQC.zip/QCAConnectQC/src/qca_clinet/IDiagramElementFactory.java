package qca_clinet  ;

import com4j.*;

/**
 * Services for managing Diagram Element.
 */
@IID("{BF2FDF47-5BB5-4CD4-812D-C086C3FB2908}")
public interface IDiagramElementFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
