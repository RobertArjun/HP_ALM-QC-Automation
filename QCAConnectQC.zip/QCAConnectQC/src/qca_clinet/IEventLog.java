package qca_clinet  ;

import com4j.*;

/**
 * For HP use. An EventLog entity.
 */
@IID("{CAD50A8B-571C-4162-BA0C-A00CA256750B}")
public interface IEventLog extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
