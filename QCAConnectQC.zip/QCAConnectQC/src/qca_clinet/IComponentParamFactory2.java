package qca_clinet  ;

import com4j.*;

/**
 * Services for managing Component parameters.
 */
@IID("{D9335C7D-8F16-4354-B862-E39978565860}")
public interface IComponentParamFactory2 extends qca_clinet.IComponentParamFactory {
  // Methods:
  /**
   * <p>
   * For HP use. Delete component parameters and automatically delete parameter from the test level  , that became unused by the component parameters deletion
   * </p>
   * @param itemKey Mandatory java.lang.Object parameter.
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(9) //= 0x9. The runtime will prefer the VTID if present
  @VTID(17)
  java.lang.String removeItemAndAutoDeleteFromTestLevel(
    @MarshalAs(NativeType.VARIANT) java.lang.Object itemKey);


  // Properties:
}
