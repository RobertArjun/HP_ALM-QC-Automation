package qca_clinet  ;

import com4j.*;

/**
 * Services for managing Component parameters.
 */
@IID("{BA09BFAF-9B3D-4A3C-B186-8723613A80F2}")
public interface IComponentParam3 extends qca_clinet.IComponentParam2 {
  // Methods:
  /**
   * <p>
   * For HP use. Promote the component parameter to the test level for the tests that contain the component
   * </p>
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(24) //= 0x18. The runtime will prefer the VTID if present
  @VTID(35)
  java.lang.String promoteToTestLevel();


  // Properties:
}
