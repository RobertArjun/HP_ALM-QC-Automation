package qca_clinet  ;

import com4j.*;

/**
 * Additional properties of the customization field.
 */
@IID("{4AB48AF3-DF92-438C-A354-143DBF378099}")
public interface ICustomizationField7 extends qca_clinet.ICustomizationField6 {
  // Methods:
  /**
   * <p>
   * Marks field as supporting/not supporting datahiding.
   * </p>
   * <p>
   * Getter method for the COM property "IsSupportDataHiding"
   * </p>
   * @return  Returns a value of type boolean
   */

  @DISPID(57) //= 0x39. The runtime will prefer the VTID if present
  @VTID(104)
  boolean isSupportDataHiding();


  // Properties:
}
