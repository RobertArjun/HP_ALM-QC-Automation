package qca_clinet  ;

import com4j.*;

/**
 */
public enum ESTORAGE_STATISTIC_ACTION_STATUS {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  OPERTION_INITIALIZING, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  OPERATION_IN_PROGRESS, // 1
  /**
   * <p>
   * The value of this constant is 2
   * </p>
   */
  OPERATION_FINISHED, // 2
}
