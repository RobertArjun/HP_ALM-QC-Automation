package qca_clinet  ;

import com4j.*;

/**
 * Services for managing BP component.
 */
@IID("{947C131A-E338-4E53-AC1F-94F4929C117D}")
public interface IBPComponentFactory2 extends qca_clinet.IBPComponentFactory {
  // Methods:
  /**
   * <p>
   * For HP use. Delete BP component and automatically delete parameters from the test level  , that became unused by the component instances deletion
   * </p>
   * @param itemKey Mandatory java.lang.Object parameter.
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(14) //= 0xe. The runtime will prefer the VTID if present
  @VTID(21)
  java.lang.String removeItemAndAutoDeleteParametersFromTestLevel(
    @MarshalAs(NativeType.VARIANT) java.lang.Object itemKey);


  // Properties:
}
