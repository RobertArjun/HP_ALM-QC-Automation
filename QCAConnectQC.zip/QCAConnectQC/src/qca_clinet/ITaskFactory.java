package qca_clinet  ;

import com4j.*;

/**
 * Services for managing asynchronous actions.
 */
@IID("{E085BBE5-BC0F-4E0C-AE70-23030B7464FA}")
public interface ITaskFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
