package qca_clinet  ;

import com4j.*;

/**
 * Services for managing CoverageEntity objects.
 */
@IID("{FD167DFE-8DEE-4930-AFAA-A83C2B1480EB}")
public interface ICoverageFactory extends qca_clinet.IBaseFactory {
  // Methods:
  // Properties:
}
