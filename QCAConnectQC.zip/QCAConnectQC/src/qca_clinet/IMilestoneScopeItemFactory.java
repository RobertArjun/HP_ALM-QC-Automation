package qca_clinet  ;

import com4j.*;

/**
 * MilestoneScopeItem Factory
 */
@IID("{87A3FD70-7FBA-41E9-B6B6-41BE00EA5CB1}")
public interface IMilestoneScopeItemFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
