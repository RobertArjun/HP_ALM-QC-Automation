package qca_clinet  ;

import com4j.*;

/**
 * Represents a folder or an asset file stored in the repository.
 */
@IID("{5B4DD596-B8A5-4D17-AA54-F8463C02C998}")
public interface IAssetRepositoryItem extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
