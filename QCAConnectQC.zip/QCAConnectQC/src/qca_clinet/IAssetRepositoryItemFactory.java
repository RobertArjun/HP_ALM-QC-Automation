package qca_clinet  ;

import com4j.*;

/**
 * Services for managing asset repository items.
 */
@IID("{AAF88415-9EAF-46C3-A3B4-605FBC798AD4}")
public interface IAssetRepositoryItemFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
