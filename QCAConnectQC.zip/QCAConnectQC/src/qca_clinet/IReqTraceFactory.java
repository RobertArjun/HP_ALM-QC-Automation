package qca_clinet  ;

import com4j.*;

/**
 * Services for managing traceability associations between requirements.
 */
@IID("{59AFC6E7-D640-401D-80C4-934340993704}")
public interface IReqTraceFactory extends qca_clinet.IBaseFactory {
  // Methods:
  // Properties:
}
