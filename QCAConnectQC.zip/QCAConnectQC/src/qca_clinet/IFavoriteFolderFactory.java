package qca_clinet  ;

import com4j.*;

/**
 * Services to manage favorite folders.
 */
@IID("{28B25C71-CA6A-4A6E-8939-5233DB3569FC}")
public interface IFavoriteFolderFactory extends qca_clinet.IBaseFactoryEx {
  // Methods:
  // Properties:
}
