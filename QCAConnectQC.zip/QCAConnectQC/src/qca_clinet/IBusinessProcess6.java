package qca_clinet  ;

import com4j.*;

/**
 * Represents a single Business Process Test.
 */
@IID("{D03A68D0-18A6-463E-963A-5E8C8C0AF07A}")
public interface IBusinessProcess6 extends qca_clinet.IBusinessProcess5 {
  // Methods:
  /**
   * <p>
   * Generates an XML description of the BPT.
   * </p>
   * @param showDesignSteps Mandatory boolean parameter.
   * @param testInstId Mandatory int parameter.
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(137) //= 0x89. The runtime will prefer the VTID if present
  @VTID(85)
  java.lang.String generateXMLDescriptionForInstance(
    boolean showDesignSteps,
    int testInstId);


  // Properties:
}
