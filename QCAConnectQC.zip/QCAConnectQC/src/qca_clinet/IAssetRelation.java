package qca_clinet  ;

import com4j.*;

/**
 * Represents a directed relation between two assets.
 */
@IID("{0FB3E674-1B0E-4688-847C-A73534F3C28E}")
public interface IAssetRelation extends qca_clinet.IBaseField {
  // Methods:
  // Properties:
}
