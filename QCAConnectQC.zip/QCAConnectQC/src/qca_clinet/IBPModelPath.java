package qca_clinet  ;

import com4j.*;

/**
 * Business Process Model Path.
 */
@IID("{EC659820-2051-4BF6-A3C5-97165298FE1D}")
public interface IBPModelPath extends qca_clinet.IBaseFieldExMail {
  // Methods:
  // Properties:
}
